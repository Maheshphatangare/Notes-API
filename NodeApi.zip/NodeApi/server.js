
// const express = require('express');
// const { initializeApp } = require('firebase-admin/app');
// const { getFirestore } = require('firebase-admin/firestore');
// const notesRoutes = require('./routes/notes');
// require('dotenv').config();
// const admin = require('firebase-admin');

// const app = express();

// // Debug environment variables
// console.log('FIREBASE_PROJECT_ID:', process.env.FIREBASE_PROJECT_ID);
// console.log('FIREBASE_CLIENT_EMAIL:', process.env.FIREBASE_CLIENT_EMAIL);
// console.log('FIREBASE_PRIVATE_KEY:', process.env.FIREBASE_PRIVATE_KEY);

// // Initialize Firebase Admin
// try {
//   admin.initializeApp({
//     credential: admin.credential.cert({
//       projectId: process.env.FIREBASE_PROJECT_ID,
//       privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
//       clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
//     }),
//   });
// } catch (error) {
//   console.error('Firebase initialization error:', error);
//   process.exit(1);
// }

// const db = getFirestore();

// // Middleware
// app.use(express.json());

// // Routes
// app.use('/notes', notesRoutes(db));

// const PORT = process.env.PORT || 3000;
// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });
const express = require('express');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const notesRoutes = require('./routes/notes');
const admin = require('firebase-admin');

const app = express();

// Initialize Firebase Admin
try {
  admin.initializeApp({
    credential: admin.credential.cert('./notes-api-firebase-adminsdk.json'), // Update to exact file name
  });
} catch (error) {
  console.error('Firebase initialization error:', error);
  process.exit(1);
}

const db = getFirestore(); // Connects to (default) database

// Middleware
app.use(express.json());

// Routes
app.use('/notes', notesRoutes(db));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});