// const express = require('express');
// const { body, param, validationResult } = require('express-validator');
// const router = express.Router();

// module.exports = (db) => {
//   // Create a new note
//   router.post(
//     '/',
//     [
//       body('title').notEmpty().withMessage('Title is required'),
//       body('content').notEmpty().withMessage('Content is required'),
//     ],
//     async (req, res) => {
//       try {
//         const errors = validationResult(req);
//         if (!errors.isEmpty()) {
//           return res.status(400).json({ errors: errors.array() });
//         }

//         const { title, content } = req.body;
//         const note = {
//           title,
//           content,
//           createdAt: new Date().toISOString(),
//           updatedAt: new Date().toISOString(),
//         };

//         const docRef = await db.collection('notes').add(note);
//         res.status(201).json({ id: docRef.id, ...note });
//       } catch (error) {
//         res.status(500).json({ error: 'Failed to create note' });
//       }
//     }
//   );

//   // Get all notes
//   router.get('/', async (req, res) => {
//     try {
//       const snapshot = await db.collection('notes').get();
//       const notes = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
//       res.status(200).json(notes);
//     } catch (error) {
//       res.status(500).json({ error: 'Failed to fetch notes' });
//     }
//   });

//   // Get a single note by ID
//   router.get(
//     '/:id',
//     [param('id').notEmpty().withMessage('Note ID is required')],
//     async (req, res) => {
//       try {
//         const errors = validationResult(req);
//         if (!errors.isEmpty()) {
//           return res.status(400).json({ errors: errors.array() });
//         }

//         const noteId = req.params.id;
//         const doc = await db.collection('notes').doc(noteId).get();

//         if (!doc.exists) {
//           return res.status(404).json({ error: 'Note not found' });
//         }

//         res.status(200).json({ id: doc.id, ...doc.data() });
//       } catch (error) {
//         res.status(500).json({ error: 'Failed to fetch note' });
//       }
//     }
//   );

//   // Update a note
//   router.put(
//     '/:id',
//     [
//       param('id').notEmpty().withMessage('Note ID is required'),
//       body('title').optional().notEmpty().withMessage('Title cannot be empty'),
//       body('content').optional().notEmpty().withMessage('Content cannot be empty'),
//     ],
//     async (req, res) => {
//       try {
//         const errors = validationResult(req);
//         if (!errors.isEmpty()) {
//           return res.status(400).json({ errors: errors.array() });
//         }

//         const noteId = req.params.id;
//         const { title, content } = req.body;
//         const updateData = {
//           ...(title && { title }),
//           ...(content && { content }),
//           updatedAt: new Date().toISOString(),
//         };

//         const docRef = db.collection('notes').doc(noteId);
//         const doc = await docRef.get();

//         if (!doc.exists) {
//           return res.status(404).json({ error: 'Note not found' });
//         }

//         await docRef.update(updateData);
//         res.status(200).json({ id: noteId, ...doc.data(), ...updateData });
//       } catch (error) {
//         res.status(500).json({ error: 'Failed to update note' });
//       }
//     }
//   );

//   // Delete a note
//   router.delete(
//     '/:id',
//     [param('id').notEmpty().withMessage('Note ID is required')],
//     async (req, res) => {
//       try {
//         const errors = validationResult(req);
//         if (!errors.isEmpty()) {
//           return res.status(400).json({ errors: errors.array() });
//         }

//         const noteId = req.params.id;
//         const docRef = db.collection('notes').doc(noteId);
//         const doc = await docRef.get();

//         if (!doc.exists) {
//           return res.status(404).json({ error: 'Note not found' });
//         }

//         await docRef.delete();
//         res.status(204).send();
//       } catch (error) {
//         res.status(500).json({ error: 'Failed to delete note' });
//       }
//     }
//   );

//   return router;
// };
const express = require('express');
const { body, param, validationResult } = require('express-validator');
const router = express.Router();

module.exports = (db) => {
  // Create a new note
//  

router.post(
    '/',
    [
      body('title').notEmpty().withMessage('Title is required'),
      body('content').notEmpty().withMessage('Content is required'),
    ],
    async (req, res) => {
      try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
          return res.status(400).json({ errors: errors.array() });
        }
  
        const { title, content } = req.body;
        const note = {
          title,
          content,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
  
        const docRef = await db.collection('notes').add(note);
        res.status(201).json({ id: docRef.id, ...note });
      } catch (error) {
        console.error('Error creating note:', error);
        res.status(500).json({ error: 'Failed to create note' });
      }
    }
  );
  // Other routes (GET, GET/:id, PUT/:id, DELETE/:id)
  router.get('/', async (req, res) => {
    try {
      const snapshot = await db.collection('notes').get();
      const notes = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.status(200).json(notes);
    } catch (error) {
      console.error('Error fetching notes:', error);
      res.status(500).json({ error: 'Failed to fetch notes' });
    }
  });

  router.get(
    '/:id',
    [param('id').notEmpty().withMessage('Note ID is required')],
    async (req, res) => {
      try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
          return res.status(400).json({ errors: errors.array() });
        }

        const noteId = req.params.id;
        const doc = await db.collection('notes').doc(noteId).get();

        if (!doc.exists) {
          return res.status(404).json({ error: 'Note not found' });
        }

        res.status(200).json({ id: doc.id, ...doc.data() });
      } catch (error) {
        console.error('Error fetching note:', error);
        res.status(500).json({ error: 'Failed to fetch note' });
      }
    }
  );

  router.put(
    '/:id',
    [
      param('id').notEmpty().withMessage('Note ID is required'),
      body('title').optional().notEmpty().withMessage('Title cannot be empty'),
      body('content').optional().notEmpty().withMessage('Content cannot be empty'),
    ],
    async (req, res) => {
      try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
          return res.status(400).json({ errors: errors.array() });
        }

        const noteId = req.params.id;
        const { title, content } = req.body;
        const updateData = {
          ...(title && { title }),
          ...(content && { content }),
          updatedAt: new Date().toISOString(),
        };

        const docRef = db.collection('notes').doc(noteId);
        const doc = await docRef.get();

        if (!doc.exists) {
          return res.status(404).json({ error: 'Note not found' });
        }

        await docRef.update(updateData);
        res.status(200).json({ id: noteId, ...doc.data(), ...updateData });
      } catch (error) {
        console.error('Error updating note:', error);
        res.status(500).json({ error: 'Failed to update note' });
      }
    }
  );

  router.delete(
    '/:id',
    [param('id').notEmpty().withMessage('Note ID is required')],
    async (req, res) => {
      try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
          return res.status(400).json({ errors: errors.array() });
        }

        const noteId = req.params.id;
        const docRef = db.collection('notes').doc(noteId);
        const doc = await docRef.get();

        if (!doc.exists) {
          return res.status(404).json({ error: 'Note not found' });
        }

        await docRef.delete();
        res.status(204).send();
      } catch (error) {
        console.error('Error deleting note:', error);
        res.status(500).json({ error: 'Failed to delete note' });
      }
    }
  );

  return router;
};